﻿# EchoBot hosted in ASP.NET Core
This sample shows how to integrate a simple EchoBot bot with ASP.Net Core 2. 